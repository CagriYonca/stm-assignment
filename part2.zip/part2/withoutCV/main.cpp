#include "jpeg.h"
#include "conv.h"
#include <iostream>

using namespace std;

int main( int argc, char* argv[] )
{
    using namespace marengo::jpeg;
    
    // Initialize image and output output vector array
    Image img( argv[1] );

    vector<vector<vector<float>>> filtered_img;

    // Customize your filter mask
    vector<vector<vector<float>>> filter_mask {
        {{1,2,3}, {1,2,3}, {1,2,3}},
        {{1,2,3}, {1,2,3}, {1,2,3}},
        {{1,2,3}, {1,2,3}, {1,2,3}} };
    
    // Set filter size
    int division_factor[3] = {9, 18, 27};

    // Filter image with mask and divide to division factor
    filtered_img = filterImage(img, filter_mask, division_factor);

    // Transform vector array to image and save
    img.transform(filtered_img);
    img.save("filtered_without_cv.jpg", 100);

    return 0;
}
