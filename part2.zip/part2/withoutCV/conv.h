#pragma once
#include "jpeg.h"
#include <vector>
using namespace std;

vector<vector<vector<float>>> filterImage(marengo::jpeg::Image &img, vector<vector<vector<float>>> &filter, int divison_factor[]);