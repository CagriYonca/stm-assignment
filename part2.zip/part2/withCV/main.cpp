#include <iostream>
#include "opencv2/imgproc.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/highgui.hpp"
#include <cmath>

using namespace std;
using namespace cv;

int main( int argc, char ** argv )
{
	// Initialize matrixes for reading image
	Mat src, dst, dst_channels[3], src_channels[3];
	src = imread( argv[1] );
	dst = src.clone();

	// Split input to channels
	split( src, src_channels );


	// Define kernels for all channels (kernel)
	float kernels[3][9] = {{1,1,1,1,1,1,1,1,1},
						{2,2,2,2,2,2,2,2,2},
						{3,3,3,3,3,3,3,3,3}};
	int kernel_size = int(sqrt(sizeof(kernels[0]) / sizeof(*kernels[0])));

	// Define division factor if exists
	int division_factor[3] = {9,18,27};
	
	// Divide channels by division factors
	if(division_factor[0] != 0)
	{
		for(int d = 0; d < 3; d++)
		{
			for(int i = 0; i < kernel_size * kernel_size ; i++)
			{
				kernels[d][i] /= division_factor[d];
			}						
		}
	}

	// Initialize filter masks
	Mat filter_maskR = Mat(kernel_size, kernel_size, CV_32F, kernels[0]);
	Mat filter_maskG = Mat(kernel_size, kernel_size, CV_32F, kernels[1]);
	Mat filter_maskB = Mat(kernel_size, kernel_size, CV_32F, kernels[2]);
	
	// Make 3D mask vector
	vector<Mat> filter_masks;
	filter_masks.push_back(filter_maskR);
	filter_masks.push_back(filter_maskG);
	filter_masks.push_back(filter_maskB);

	// Convolve through all dimensions
	for(int d = 0; d < int(filter_masks.size()); d++)
	{
		filter2D( src_channels[d], dst_channels[d], -1, filter_masks[d]);
	}

	// Initialize channels for output image
	vector<Mat> channel_vector;
	channel_vector.push_back(dst_channels[0]);
	channel_vector.push_back(dst_channels[1]);
	channel_vector.push_back(dst_channels[2]);

	// Merge all channels
	merge(channel_vector, dst);

	// Save image
	imwrite("filtered_with_cv.jpg", dst);

	return 0;
}
